import tkinter as tk
import nltk
from textblob import TextBlob
from newspaper import Article

# Download NLTK data for tokenization
nltk.download('punkt')

# Function to summarize the news article and perform sentiment analysis
def summarize_news():
    # Get the URL entered by the user
    url = url_entry.get()

    # Initialize and parse the article
    article = Article(url)
    article.download()
    article.parse()
    article.nlp()

    # Update the text widgets with article information
    title.config(state='normal')
    title.delete(1.0, tk.END)
    title.insert(tk.END, article.title)
    title.config(state='disabled')

    author.config(state='normal')
    author.delete(1.0, tk.END)
    author.insert(tk.END, ', '.join(article.authors))
    author.config(state='disabled')

    publications.config(state='normal')
    publications.delete(1.0, tk.END)
    publications.insert(tk.END, str(article.publish_date))
    publications.config(state='disabled')

    summary.config(state='normal')
    summary.delete(1.0, tk.END)
    summary.insert(tk.END, article.summary)
    summary.config(state='disabled')

    # Perform sentiment analysis using TextBlob
    analysis = TextBlob(article.text)
    sentiment.config(state='normal')
    sentiment.delete(1.0, tk.END)
    sentiment.insert(tk.END, f'Sentiment: {"positive" if analysis.sentiment.polarity > 0 else "negative" if analysis.sentiment.polarity < 0 else "neutral"}')
    sentiment.config(state='disabled')

# Create the main Tkinter window
root = tk.Tk()
root.title("News Summarizer")
root.geometry('1200x600')

# Label and entry for entering the URL
url_label = tk.Label(root, text="Enter URL:")
url_label.pack()

url_entry = tk.Entry(root, width=100)
url_entry.pack()

# Button to trigger summarization
summarize_button = tk.Button(root, text="Summarize", command=summarize_news)
summarize_button.pack()

# Label and text widgets for displaying article information
tlabel = tk.Label(root, text="Title")
tlabel.pack()

title = tk.Text(root, height=1, width=140)
title.config(state='disabled', bg='#dddddd')
title.pack()

alabel = tk.Label(root, text="Author")
alabel.pack()

author = tk.Text(root, height=1, width=140)
author.config(state='disabled', bg='#dddddd')
author.pack()

plabel = tk.Label(root, text="Publishing Date")
plabel.pack()

publications = tk.Text(root, height=1, width=140)
publications.config(state='disabled', bg='#dddddd')
publications.pack()

slabel = tk.Label(root, text="Summary")
slabel.pack()

summary = tk.Text(root, height=20, width=140)
summary.config(state='disabled', bg='#dddddd')
summary.pack()

# Label and text widget for displaying sentiment analysis
selabel = tk.Label(root, text="Sentimental Analysis")
selabel.pack()

sentiment = tk.Text(root, height=1, width=140)
sentiment.config(state='disabled', bg='#dddddd')
sentiment.pack()

# Start the Tkinter main loop
root.mainloop()
